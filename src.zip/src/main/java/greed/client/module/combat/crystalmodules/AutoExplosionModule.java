package greed.client.module.combat.crystalmodules;

import greed.client.event.EventListener;
import greed.client.event.PacketEvent;
import greed.client.event.PlayerTickEvent;
import greed.client.module.ModuleCategory;
import greed.client.module.ModuleInfo;
import greed.client.setting.BooleanSetting;
import greed.client.setting.MultiSelectSetting;
import greed.client.util.InventoryUtils;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

@ModuleInfo(
        name = "AutoExplosion",
        description = "Автоматически подрывает поставленный кристалл эндера или якорь возрождения.",
        category = ModuleCategory.COMBAT
)
public final class AutoExplosionModule extends CrystalModule {
    private static AutoExplosionModule instance;

    private static final String TRIGGER_CRYSTALS = "Кристаллы";
    private static final String TRIGGER_ANCHORS = "Якоря";

    private static final int STAGE_IDLE = 0;
    private static final int STAGE_CHARGE = 1;
    private static final int STAGE_EXPLODE = 2;
    private static final int MAX_WAIT_TICKS = 10;
    private static final double MAX_ANCHOR_DISTANCE_SQ = 36.0;
    private static final double POINT_INSET = 0.05;

    private Random random = new Random();

    private final BooleanSetting crystals = this.addSetting(
            new BooleanSetting("Кристаллы", "Подрывать кристаллы эндера.", true)
    );
    private final BooleanSetting anchor = this.addSetting(
            new BooleanSetting("Якоря возрождения", "Взаимодействовать с якорями возрождения.", true)
    );
    private final MultiSelectSetting triggers = this.addSetting(
            new MultiSelectSetting(
                    "Триггеры",
                    "Какие цели обрабатывать автоматически.",
                    new String[]{TRIGGER_CRYSTALS, TRIGGER_ANCHORS},
                    TRIGGER_CRYSTALS,
                    TRIGGER_ANCHORS
            )
    );
    private final BooleanSetting anyItemClick = this.addSetting(
            new BooleanSetting(
                    "Любым предметом",
                    "Реагировать на клик по блоку любым предметом, а не только кристаллом или светокамнем.",
                    false
            )
    );
    private final BooleanSetting resetSlot = this.addSetting(
            new BooleanSetting("Возвращать слот", "Возвращать исходный слот после срабатывания.", false)
    );

    private BlockPos detonateTarget;
    private BlockPos placeTarget;
    private BlockPos anchorTarget;

    private int anchorStage = STAGE_IDLE;
    private int anchorWait;
    private int anchorPrevSlot = -1;

    private boolean useKeyWasPressed;

    private final EventListener<PlayerTickEvent> tickListener = event -> {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            this.resetTargets();
            this.useKeyWasPressed = false;
            return;
        }

        if (this.detonateTarget != null) {
            if (this.detonateCrystal(this.detonateTarget)) {
                this.detonateTarget = null;
            }
            return;
        }

        if (this.placeTarget != null) {
            if (this.placeCrystal(this.placeTarget)) {
                this.placeTarget = null;
            }
            return;
        }

        if (this.anchorTarget != null) {
            if (this.useAnchor(this.anchorTarget)) {
                this.anchorTarget = null;
            }
            return;
        }

        this.detectClick();
    };

    private final EventListener<PacketEvent> packetListener = event -> {
        if (!event.isIncoming() || mc.world == null || mc.player == null || !this.isEnabled()) {
            return;
        }

        Packet<?> packet = event.getPacket();
        if (!(packet instanceof BlockUpdateS2CPacket update)) {
            return;
        }

        BlockPos pos = update.getPos().toImmutable();
        Block block = update.getState().getBlock();

        if (this.anchorEnabled()
                && block == Blocks.RESPAWN_ANCHOR
                && update.getState().get(RespawnAnchorBlock.CHARGES) == 0) {
            mc.execute(() -> {
                if (mc.player == null
                        || this.anchorTarget != null
                        || this.anchorStage != STAGE_IDLE) {
                    return;
                }
                if (mc.player.squaredDistanceTo(pos.toCenterPos()) > MAX_ANCHOR_DISTANCE_SQ) {
                    return;
                }
                this.anchorTarget = pos;
            });
        } else if (this.crystalsEnabled() && this.isCrystalSurface(block)) {
            mc.execute(() -> {
                if (this.detonateTarget == null && this.findCrystal(pos) != null) {
                    this.detonateTarget = pos;
                }
            });
        }
    };

    private void detectClick() {
        boolean pressed = mc.options.useKey.isPressed();

        if (pressed && !this.useKeyWasPressed && mc.crosshairTarget instanceof BlockHitResult hit) {
            BlockPos pos = hit.getBlockPos();
            Block block = mc.world.getBlockState(pos).getBlock();
            ItemStack held = mc.player.getStackInHand(Hand.MAIN_HAND);

            if (this.crystalsEnabled() && this.isCrystalSurface(block)) {
                if (this.findCrystal(pos) != null) {
                    if (held.isOf(Items.END_CRYSTAL) || this.anyItemClick.isChecked()) {
                        this.detonateTarget = pos;
                    }
                } else {
                    if (held.isOf(Items.END_CRYSTAL) || this.anyItemClick.isChecked()) {
                        this.placeTarget = pos;
                    }
                }
            } else if (this.anchorEnabled()
                    && block == Blocks.RESPAWN_ANCHOR
                    && (held.isOf(Items.GLOWSTONE)
                    || held.isOf(Items.END_CRYSTAL)
                    || held.isOf(Items.RESPAWN_ANCHOR)
                    || this.anyItemClick.isChecked())) {
                this.anchorTarget = pos;
                this.anchorStage = STAGE_IDLE;
            }
        }

        this.useKeyWasPressed = pressed;
    }

    private Vec3d findNearestCrystalPoint(EndCrystalEntity crystal) {
        Vec3d eyes = mc.player.getEyePos();
        Box box = crystal.getBoundingBox().contract(POINT_INSET);

        double x = MathHelper.clamp(eyes.x, box.minX, box.maxX) + random.nextDouble(0.01,0.25);
        double y = MathHelper.clamp(eyes.y, box.minY, box.maxY) + random.nextDouble(0.01,0.25);
        double z = MathHelper.clamp(eyes.z, box.minZ, box.maxZ) + random.nextDouble(0.01,0.25);

        Vec3d point = new Vec3d(x, y, z);
        if (point.squaredDistanceTo(eyes) < 1.0E-6) {
            return box.getCenter();
        }
        return point;
    }

//    @Override
//    public void aimAt(Vec3d point) {
//        Vec3d eyes = mc.player.getEyePos();
//        double dx = point.x - eyes.x;
//        double dy = point.y - eyes.y;
//        double dz = point.z - eyes.z;
//        double horizontal = Math.sqrt(dx * dx + dz * dz);
//
//        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
//        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
//
//        mc.player.setYaw(MathHelper.wrapDegrees(yaw));
//        mc.player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
//    }

    private boolean detonateCrystal(BlockPos pos) {
        EndCrystalEntity crystal = this.findCrystal(pos);
        if (crystal == null) {
            return true;
        }

        double reach = mc.player.getEntityInteractionRange();
        Vec3d point = this.findNearestCrystalPoint(crystal);
        if (mc.player.getEyePos().squaredDistanceTo(point) > reach * reach) {
            return true;
        }

        this.aimAt(point);

        mc.interactionManager.attackEntity(mc.player, crystal);
        mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private boolean placeCrystal(BlockPos pos) {
        if (!this.isCrystalSurface(mc.world.getBlockState(pos).getBlock()) || this.findCrystal(pos) != null) {
            return true;
        }

        int previousSlot = InventoryUtils.getSelectedSlot();
        this.getItemFromHotBar(new ItemStack(Items.END_CRYSTAL));
        if (!mc.player.getStackInHand(Hand.MAIN_HAND).isOf(Items.END_CRYSTAL)) {
            return true;
        }

        BlockHitResult hit = this.prepareBlockInteraction(pos, true, true);
        if (hit == null) {
            return false;
        }

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);

        if (this.resetSlot.isChecked() && previousSlot != -1 && previousSlot != InventoryUtils.getSelectedSlot()) {
            InventoryUtils.setSelectedSlot(previousSlot, false);
        }
        return true;
    }

    private boolean useAnchor(BlockPos pos) {
        if (!mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR)) {
            this.finishAnchor();
            return true;
        }

        int charges = mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES);

        if (this.anchorStage == STAGE_IDLE) {
            this.anchorPrevSlot = InventoryUtils.getSelectedSlot();
            this.anchorWait = 0;
            this.anchorStage = charges == 0 ? STAGE_CHARGE : STAGE_EXPLODE;
        }

        if (this.anchorStage == STAGE_CHARGE) {
            this.getItemFromHotBar(new ItemStack(Items.GLOWSTONE));
            if (!mc.player.getStackInHand(Hand.MAIN_HAND).isOf(Items.GLOWSTONE)) {
                this.finishAnchor();
                return true;
            }

            BlockHitResult hit = this.prepareBlockInteraction(pos, false, true);
            if (hit == null) {
                return false;
            }

            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);

            this.anchorStage = STAGE_EXPLODE;
            this.anchorWait = 0;
            return false;
        }

        if (charges == 0) {
            this.anchorWait++;
            if (this.anchorWait > MAX_WAIT_TICKS) {
                this.finishAnchor();
                return true;
            }
            return false;
        }

        this.getItemFromHotBar(new ItemStack(Items.RESPAWN_ANCHOR));
        if (!mc.player.getStackInHand(Hand.MAIN_HAND).isOf(Items.RESPAWN_ANCHOR)) {
            this.finishAnchor();
            return true;
        }

        BlockHitResult hit = this.prepareBlockInteraction(pos, false, true);
        if (hit == null) {
            return false;
        }

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);

        this.finishAnchor();
        return true;
    }

    private void finishAnchor() {
        int previousSlot = this.anchorPrevSlot;
        this.anchorStage = STAGE_IDLE;
        this.anchorWait = 0;
        this.anchorPrevSlot = -1;

        if (this.resetSlot.isChecked() && previousSlot != -1 && previousSlot != InventoryUtils.getSelectedSlot()) {
            InventoryUtils.setSelectedSlot(previousSlot, false);
        }
    }

    private EndCrystalEntity findCrystal(BlockPos pos) {
        BlockPos checkPos = this.isCrystalSurface(mc.world.getBlockState(pos).getBlock()) ? pos.up() : pos;

        for (Entity entity : mc.world.getEntitiesByClass(EndCrystalEntity.class, new Box(checkPos), Entity::isAlive)) {
            if (entity instanceof EndCrystalEntity crystal) {
                return crystal;
            }
        }
        return null;
    }

    private boolean isCrystalSurface(Block block) {
        return block == Blocks.OBSIDIAN || block == Blocks.BEDROCK;
    }

    private boolean hasCrystalSpace(BlockPos pos) {
        BlockPos above = pos.up();
        if (!mc.world.getBlockState(above).isAir()) {
            return false;
        }

        Box box = new Box(
                above.getX(), above.getY(), above.getZ(),
                above.getX() + 1.0, above.getY() + 2.0, above.getZ() + 1.0
        );
        return mc.world.getOtherEntities(null, box).isEmpty();
    }

    private boolean crystalsEnabled() {
        return this.crystals.isChecked() && this.triggers.isSelected(TRIGGER_CRYSTALS);
    }

    private boolean anchorEnabled() {
        return this.anchor.isChecked() && this.triggers.isSelected(TRIGGER_ANCHORS);
    }

    private void resetTargets() {
        this.detonateTarget = null;
        this.placeTarget = null;
        this.anchorTarget = null;
        this.anchorStage = STAGE_IDLE;
        this.anchorWait = 0;
        this.anchorPrevSlot = -1;
    }

    @Override
    protected void onEnable() {
        this.resetTargets();
        this.useKeyWasPressed = false;
    }

    @Override
    protected void onDisable() {
        this.resetTargets();
        this.useKeyWasPressed = false;
    }

    private AutoExplosionModule() {
    }

    public static AutoExplosionModule getInstance() {
        if (instance == null) {
            instance = new AutoExplosionModule();
        }
        return instance;
    }
}