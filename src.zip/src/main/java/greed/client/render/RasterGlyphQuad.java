package greed.client.render;

import greed.client.render.FontTexture;

public record RasterGlyphQuad(
   FontTexture page, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1
) {
}
